function toggle(){
    $('.ico01').click(function(){
        $('.wrapper').toggleClass('active');
    })
}

toggle();